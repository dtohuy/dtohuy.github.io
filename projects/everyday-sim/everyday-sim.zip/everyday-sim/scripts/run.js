#!/usr/bin/env node
/* Run a model headless and print KPIs, so the agent can check numbers before writing conclusions.
   Usage: node run.js model.json [param=value ...] [--reps N] [--json] [--lang zh|en] */
const path = require("path"), fs = require("fs");
const E = require(path.join(__dirname, "..", "assets", "engine.js"));
const args = process.argv.slice(2);
if (!args.length) { console.error("usage: node run.js model.json [param=value ...] [--reps N] [--json]"); process.exit(2); }
const spec = JSON.parse(fs.readFileSync(args[0], "utf8"));
const over = {}; let reps, json = false, lang = "zh";
for (let i = 1; i < args.length; i++) {
  if (args[i] === "--reps") reps = +args[++i];
  else if (args[i] === "--json") json = true;
  else if (args[i] === "--lang") lang = args[++i];
  else { const [k, v] = args[i].split("="); over[k] = +v; }
}
const errs = E.validate(spec);
if (errs.length) { console.error("模型有问题:\n- " + errs.join("\n- ")); process.exit(1); }
const t0 = Date.now();
const res = E.run(spec, over, { reps, record: false });
const out = res.kpis.map((k) => ({ id: k.id, label: E.pick(k.label, lang), mean: k.mean, lo: k.lo, hi: k.hi, unit: E.pick(k.unit, lang), reached: k.hit + "/" + k.n }));
if (json) console.log(JSON.stringify({ params: res.env, reps: res.reps, kpis: out }, null, 2));
else {
  console.log(`${E.pick(spec.title, lang)}  (${res.reps} 次重复, ${Date.now() - t0} ms)`);
  console.log("参数: " + Object.entries(res.env).map(([k, v]) => k + "=" + v).join(", "));
  for (const k of out) {
    const f = (x) => (x == null ? "—" : Math.abs(x) >= 1000 ? Math.round(x).toLocaleString() : (+x.toFixed(2)).toString());
    const rng = k.lo != null && k.hi - k.lo > 1e-9 ? `90% 范围 ${f(k.lo)} ~ ${f(k.hi)}` : "", miss = k.reached !== res.reps + "/" + res.reps ? "达到 " + k.reached : "";
    console.log(`  ${k.label}: ${f(k.mean)} ${k.unit || ""}` + (rng || miss ? `  (${[rng, miss].filter(Boolean).join(", ")})` : ""));
  }
}
