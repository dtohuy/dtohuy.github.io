#!/usr/bin/env python3
"""Bundle one or more model files into a single self-contained HTML page.

  python3 build.py model.json [more.json ...] --out sim.html [--title "..."] [--title-en "..."]
                  [--about about.html] [--about-en about.en.html] [--lang zh|en]

Validates each model with the engine first (needs node); skips validation if node is missing.
"""
import argparse, json, shutil, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ASSETS = HERE.parent / "assets"


def validate(path):
    if not shutil.which("node"):
        print("warning: node not found, skipping validation", file=sys.stderr)
        return
    js = ("const E=require(process.argv[1]);const s=JSON.parse(require('fs').readFileSync(process.argv[2],'utf8'));"
          "const e=E.validate(s);if(e.length){console.error(e.join('\\n'));process.exit(1)}")
    r = subprocess.run(["node", "-e", js, str(ASSETS / "engine.js"), str(path)], capture_output=True, text=True)
    if r.returncode:
        sys.exit(f"{path}: 模型有问题\n{r.stderr.strip()}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("models", nargs="+")
    ap.add_argument("--out", default="sim.html")
    ap.add_argument("--title")
    ap.add_argument("--title-en")
    ap.add_argument("--about", help="HTML fragment shown in a 说明 tab")
    ap.add_argument("--about-en", help="English version of the about fragment")
    ap.add_argument("--lang", default="zh", choices=["zh", "en"], help="language shown first")
    a = ap.parse_args()
    models = []
    for m in a.models:
        validate(m)
        models.append(json.loads(Path(m).read_text(encoding="utf-8")))
    ids = [m.get("id") or f"m{i}" for i, m in enumerate(models)]
    for m, i in zip(models, ids):
        m["id"] = i
    def pick(v, lang):
        return v.get(lang) or v.get("zh") or v.get("en") if isinstance(v, dict) else v
    title = a.title or (pick(models[0]["title"], "zh") if len(models) == 1 else "模拟实验室")
    title_en = a.title_en or (pick(models[0]["title"], "en") if len(models) == 1 else "Simulation lab")
    about = None
    if a.about:
        about = {"zh": Path(a.about).read_text(encoding="utf-8")}
        if a.about_en:
            about["en"] = Path(a.about_en).read_text(encoding="utf-8")
    data = {"title": {"zh": title, "en": title_en}, "lang": a.lang, "models": models,
            "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "about": about}
    html = (ASSETS / "template.html").read_text(encoding="utf-8")
    html = html.replace("/*__ENGINE__*/", (ASSETS / "engine.js").read_text(encoding="utf-8"))
    html = html.replace("__SIM_JSON__", json.dumps(data, ensure_ascii=False).replace("</", "<\\/"))
    html = html.replace("__SIM_TITLE__", (title if a.lang == "zh" else title_en).replace("<", "&lt;"))
    out = Path(a.out)
    out.write_text(html, encoding="utf-8")
    print(f"built {len(models)} model(s) -> {out.resolve()}")


if __name__ == "__main__":
    main()
