# Recipes for common questions

Start from the closest recipe and rename things into the user's words.

## Flow / queue (`des`)

| Question | Blocks | Key params | KPIs to show |
|---|---|---|---|
| How many staff at the counter / clinic / service desk? | source → service(staff) → sink | arrivals per hour, service time, staff | wait, people lost, utilization |
| Where is the bottleneck in my process? | source → service A → service B → … → sink | time and staff per step | utilization per step (highest = bottleneck) |
| Do I have enough seats / beds / parking? | source → service(counter) → select → service(seats) → sink | stay time, seat count | seat queue and wait |
| Will orders ship today? | source(orders, `limit`) → service(pick) → service(pack) → sink | orders per day, workers | completed count vs created |
| Is it worth adding a self-service kiosk? | source → select(kiosk share) → service(kiosk) / service(staff) → sink | kiosk share, kiosk time | wait by route |

Arrivals: convert "about 40 per hour" to `interarrival` mean = 60/40 = 1.5 minutes with `exp`.
Durations: ask "fastest / usual / slowest" and use `tri`.

## Stock and flow (`sd`)

| Question | Stocks | Flows |
|---|---|---|
| When will I reach my savings goal? | balance | +monthly saving, +interest = balance × rate / 12 |
| How long to pay off this debt? | debt (min 0) | +interest = debt × rate / 12, −payment = min(payment, debt + interest) |
| When will I run out of stock? | inventory (min 0) | +restock, −sales |
| How will my weight change? | weight | +(calories in − calories out) / 7700 per day |
| How many followers in a year? | followers | +new = followers × growth rate, −unfollow = followers × churn |

Use `firstTime` KPIs for "when will I reach…" questions, with `valueParam` pointing at the goal parameter.

## Individuals (`abm`)

| Question | States | Transitions |
|---|---|---|
| How fast will word of mouth spread? (Bass) | potential → customer → lapsed | ad rate; contact with customer; churn rate |
| How fast will a cold spread in the office? (SIR) | healthy → sick → recovered | contact with sick; recovery rate 1/days |
| Will a rumor die out? | unaware → spreading → bored | contact with spreading; boredom rate |
| How many people will adopt the new habit? | not yet → trying → habit / gave up | invite contact; rate to habit; rate to gave up |

Keep population between 200 and 3000 so the page stays fast. Express rates per day.
