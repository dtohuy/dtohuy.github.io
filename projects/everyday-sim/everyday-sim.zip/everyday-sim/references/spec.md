# Model file format

One JSON object per model. Full working examples are in `examples/`.

## Common fields

| Field | Required | Notes |
|---|---|---|
| `id` | no | ASCII, used for slider ids. Defaults to file order. |
| `title` | yes | Short question-like name: "咖啡店午间要几个店员". |
| `question` | no | The user's question in their words. |
| `method` | yes | `des`, `sd` or `abm`. |
| `time.unit` | yes | Display unit: 分钟, 天, 月… |
| `time.horizon` | yes | How long to simulate, in that unit. |
| `time.dt` | sd/abm | Step size. Default 1. |
| `time.points` | no | Number of samples kept for charts and animation (max 400). Default 200. |
| `replications` | no | Repeated random runs (des/abm). Default 20. |
| `params` | yes | List of `{id, label, value, min, max, step, unit}`. `id` must be ASCII letters, digits, underscore. |
| `kpis` | no | See below. |
| `charts` | no | `[{title, vars:[series ids]}]`. Defaults are chosen per method. |
| `assumptions`, `limits`, `insights` | no | Lists of plain-language sentences. |

## Two languages

Any text field (`title`, `question`, `label`, `unit`, chart `title`, `assumptions`, `limits`, `insights`) can be a plain string or `{"zh": "…", "en": "…"}`. For lists, put a list in each language: `"insights": {"zh": ["…"], "en": ["…"]}`. Missing languages fall back to the other one. Built-in labels and units for flow-model KPIs are already bilingual.

## Expressions

Anywhere a number is expected you can write a number or an expression string using parameter ids, for example `"makeTime*0.6"`.

Operators: `+ - * / ^ ( ) < > <= >= == != && || !`
Functions: `min max abs exp ln sqrt floor ceil round pow if(cond, a, b)`
In `sd` and `abm`, `t` is the current time. In `sd`, stock, flow and aux ids are variables. In `abm`, each state id holds the current count of agents in that state, and `N` is the population.

## Distributions (des)

`{"dist":"exp","mean":…}`, `{"dist":"uniform","min":…,"max":…}`, `{"dist":"tri","min":…,"mode":…,"max":…}`, `{"dist":"normal","mean":…,"sd":…}` (cut at 0), `{"dist":"const","value":…}`, or a plain number/expression.

Use `exp` for random arrivals, `tri` for task durations when the user can give "fastest / usual / slowest".

## des: flow model

`blocks`: list of steps an entity goes through. Each has `id`, `type`, `label`.

| type | Fields | Meaning |
|---|---|---|
| `source` | `interarrival` (distribution), `next`, optional `limit` | Creates entities. |
| `service` | `capacity`, `duration`, `next`, optional `queueMax` | Limited servers with a FIFO queue. If the queue already holds `queueMax`, new arrivals leave (counted as lost). |
| `delay` | `duration`, `next` | Takes time, unlimited capacity. |
| `select` | `branches: [{p, next}, …, {p:"rest", next}]` | Random split. `p` is a probability; `"rest"` takes what is left. |
| `sink` | — | Entities leave. |

Automatic KPIs for every service: average wait, longest queue, utilization %, people lost (if `queueMax`). Plus completed count and average time in system.
Series for charts: `inSys` (entities in the system) and `q_<serviceId>` (queue length).

## sd: stock and flow model

- `stocks`: `[{id, label, initial, unit, min}]`. `min` clamps the stock (for example 0).
- `flows`: `[{id, label, from, to, rate}]`. Leave out `from` for an inflow from outside, `to` for an outflow. `rate` is per time unit.
- `aux`: `[{id, label, expr}]`. Helper values; order does not matter, cycles are rejected.

Integration is Euler with step `dt`. Use `dt` of 1 for monthly or daily models, smaller if values change fast.

## abm: individual model

- `population`: expression for the number of agents (for example `"residents"`).
- `states`: `[{id, label, color}]`. The first state receives everyone not listed in `initial`.
- `initial`: `{stateId: count expression}`.
- `transitions`: evaluated in order; at most one fires per agent per step.
  - `{"from","to","type":"rate","rate":expr}`: happens at this rate per time unit.
  - `{"from","to","type":"contact","contacts":expr,"with":stateId,"prob":expr}`: the agent meets `contacts` random others per time unit; each one met who is in state `with` converts it with probability `prob`.
  - Optional `label` is shown on the state diagram.

Series: one per state id (count).

## kpis

`{id, label, var, type, unit, good, digits}` where `var` is a series id and `type` is one of:

- `final`, `max`, `min`, `mean`: value of the series
- `timeOfMax`: when the maximum happens
- `firstTime`: first time the series meets `op` (`>=`, `<=`, `>`, `<`) `value`. Use `valueParam` instead of `value` to compare against a parameter, so the slider moves the goal too. If a run never reaches it, the page says how many runs missed.

`good`: `low`, `high` or `mid`. It colors the change arrows on the 假如… tab.
