---
name: everyday-sim
description: Turns an everyday "what will happen if…" question into a runnable simulation and an interactive HTML page with animation, result ranges and what-if sliders, in the spirit of AnyLogic but for non-experts. Covers queues and staffing (discrete-event), accumulating totals like savings, debt or inventory (system dynamics), and people influencing each other like word of mouth or an epidemic (agent-based). Use when the user asks how many staff, counters or seats they need, how long a queue or wait will be, how long until a goal is reached, how something spreads, or asks to simulate, model or compare scenarios. Do not use for pure statistics on existing data, one-off arithmetic, or questions that need no change over time.
---

# Everyday Sim

Help a non-expert answer a "what will happen if…" question with a small simulation, then show it as a page they can play and adjust.

The user does not need to know modeling terms. Never ask them to choose a method or write formulas. Talk in their words: customers, staff, money, days.

`SKILL_DIR` below means the folder this file is in. Requires Python 3.8+ and Node 16+, no packages.

## Workflow

### 1. Understand the question

Restate it in one sentence: what decision they face, and what they want to know. Example: "You want to know whether 2 baristas are enough at lunch, judged by how long people wait and how many walk away."

### 2. Pick the method silently

| The question is about | Method | `method` |
|---|---|---|
| Things arriving, waiting, being served; staff, seats, counters, bottlenecks | Flow / queue | `des` |
| A total that builds up or drains over time: money, debt, stock, weight, followers | Stock and flow | `sd` |
| Many people changing state because of each other: word of mouth, illness, rumors | Individuals | `abm` |

`references/recipes.md` has ready-made patterns for common questions. Start from the closest one.

### 3. Ask for the numbers that matter

Ask at most 3 questions in one message. Ask only for numbers that would change the answer, in everyday units ("about how many customers per hour at the busiest time?"). For anything else, pick a reasonable default and list it as an assumption. If the user says "just guess", use defaults and say so.

### 4. Write the model file

Write a JSON model following `references/spec.md`. Rules:
- Every number the user might want to change becomes a `param` with a plain-language `label`, `unit`, and a `min`/`max` range wide enough to explore.
- `assumptions`: what the model takes as given. `limits`: what it ignores. Both in plain language, 2–5 items each.
- Add `kpis` that answer the user's actual question. Flow models get queue, utilization and throughput KPIs automatically.

### 5. Check it runs, then try what-ifs

```bash
node SKILL_DIR/scripts/run.js model.json
node SKILL_DIR/scripts/run.js model.json baristas=3
```

Add `--lang en` to print English labels.

`run.js` validates the model and prints each KPI as an average with a 90% range across repeated random runs. Fix any reported error. Sanity-check the numbers: if a result looks implausible (for example utilization above 100% or a negative balance), fix the model before going on.

Run 2–4 what-ifs that matter for the decision, such as one more staff member or a 20% busier day.

### 6. Write the conclusions

Put 2–4 sentences in `insights`, using only numbers you saw in `run.js` output. Lead with the answer to the question, then the most useful what-if. Mention the range when luck matters ("usually 4 to 14 minutes").

### 7. Build the page

The page has a 中 / EN switch. Write every text field (titles, labels, units, assumptions, insights) in the user's language. If they may share it with people who read the other language, write both as `{"zh": "…", "en": "…"}`; see `references/spec.md`.

```bash
python3 SKILL_DIR/scripts/build.py model.json --out sim.html
```

Several models can go in one page (`build.py a.json b.json --title "..."`). `--about about.html` adds a 说明 tab with an HTML fragment (`--about-en` for its English version). `--lang en` makes English the first language shown; a viewer's own choice is remembered in their browser.

The page has tabs: 动画 (playback), 结果 (KPIs with ranges, charts, insights), 假如… (sliders that re-run the model live and compare with the default), 模型结构 (diagram, parameters, assumptions), and 修正意见 (a feedback box). It is one self-contained file and needs no network.

If you can publish or display HTML (for example the Artifact tool in Claude), do that and give the link. Otherwise give the file path.

### 8. Reply briefly

Give the answer to their question first, in one or two sentences, then point them to the 假如… tab for trying their own changes. Say plainly that the model is a simplification and name the most important assumption.

## Honesty rules

- Never present a model result as a forecast of the real future. Say "in this model" or "if these assumptions hold".
- Never invent statistics about the user's business or life. Unknown inputs are labeled assumptions with a slider so the user can change them.
- If the question cannot be answered with these three methods, say so instead of forcing a model.
