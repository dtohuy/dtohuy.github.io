/* everyday-sim engine: discrete-event (des), system dynamics (sd), agent-based (abm).
   Zero dependencies. Works in the browser (window.SimEngine) and in Node (require). */
(function (root) {
  "use strict";

  /* ---------- seeded RNG ---------- */
  function rng(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6d2b79f5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /* ---------- expression language ----------
     numbers, identifiers, + - * / ^, ( ), < > <= >= == !=, && || !,
     functions: min max abs exp ln sqrt floor ceil round pow if(c,a,b) */
  const FN = {
    min: Math.min, max: Math.max, abs: Math.abs, exp: Math.exp, ln: Math.log, sqrt: Math.sqrt,
    floor: Math.floor, ceil: Math.ceil, round: Math.round, pow: Math.pow,
  };
  function tokenize(src) {
    const re = /\s*(?:(\d+\.?\d*(?:[eE][+-]?\d+)?|\.\d+)|([A-Za-z_][A-Za-z0-9_]*)|(<=|>=|==|!=|&&|\|\||[-+*/^(),<>!]))/y;
    const out = [];
    let m;
    re.lastIndex = 0;
    while (re.lastIndex < src.length) {
      const at = re.lastIndex;
      m = re.exec(src);
      if (!m) {
        if (/^\s*$/.test(src.slice(at))) break;
        throw new Error("表达式无法识别: " + src.slice(at, at + 12));
      }
      if (m[1] != null) out.push({ k: "n", v: parseFloat(m[1]) });
      else if (m[2] != null) out.push({ k: "id", v: m[2] });
      else out.push({ k: "op", v: m[3] });
    }
    return out;
  }
  function compile(src) {
    if (typeof src === "number") { const f = () => src; f.vars = new Set(); return f; }
    if (src == null || src === "") throw new Error("缺少表达式");
    const toks = tokenize(String(src));
    let i = 0;
    const vars = new Set();
    const peek = () => toks[i], eat = (v) => { const t = toks[i]; if (!t || (v && t.v !== v)) throw new Error("表达式语法错误: " + src); i++; return t; };
    const isOp = (v) => toks[i] && toks[i].k === "op" && toks[i].v === v;
    function bin(next, ops, mk) {
      return function () {
        let l = next();
        while (toks[i] && toks[i].k === "op" && ops.includes(toks[i].v)) { const op = eat().v; const r = next(); l = mk(op, l, r); }
        return l;
      };
    }
    function primary() {
      const t = peek();
      if (!t) throw new Error("表达式不完整: " + src);
      if (t.k === "n") { i++; const v = t.v; return () => v; }
      if (t.k === "id") {
        i++;
        if (isOp("(")) {
          eat("(");
          const args = [];
          if (!isOp(")")) { args.push(or()); while (isOp(",")) { eat(","); args.push(or()); } }
          eat(")");
          if (t.v === "if") { const [c, a, b] = args; return (e) => (c(e) ? a(e) : b(e)); }
          const f = FN[t.v];
          if (!f) throw new Error("不支持的函数: " + t.v);
          return (e) => f.apply(null, args.map((g) => g(e)));
        }
        const name = t.v;
        vars.add(name);
        return (e) => { const v = e[name]; if (v === undefined) throw new Error("未知变量: " + name); return v; };
      }
      if (isOp("(")) { eat("("); const x = or(); eat(")"); return x; }
      throw new Error("表达式语法错误: " + src);
    }
    function pow() { const b = primary(); if (isOp("^")) { eat("^"); const x = unary(); return (e) => Math.pow(b(e), x(e)); } return b; }
    function unary() {
      if (isOp("-")) { eat("-"); const x = unary(); return (e) => -x(e); }
      if (isOp("!")) { eat("!"); const x = unary(); return (e) => (x(e) ? 0 : 1); }
      return pow();
    }
    const mul = bin(unary, ["*", "/"], (op, l, r) => (op === "*" ? (e) => l(e) * r(e) : (e) => l(e) / r(e)));
    const add = bin(mul, ["+", "-"], (op, l, r) => (op === "+" ? (e) => l(e) + r(e) : (e) => l(e) - r(e)));
    const cmp = bin(add, ["<", ">", "<=", ">=", "==", "!="], (op, l, r) => ({
      "<": (e) => +(l(e) < r(e)), ">": (e) => +(l(e) > r(e)), "<=": (e) => +(l(e) <= r(e)),
      ">=": (e) => +(l(e) >= r(e)), "==": (e) => +(l(e) === r(e)), "!=": (e) => +(l(e) !== r(e)),
    })[op]);
    const and = bin(cmp, ["&&"], (op, l, r) => (e) => +(l(e) && r(e)));
    const or = bin(and, ["||"], (op, l, r) => (e) => +(l(e) || r(e)));
    const f = or();
    if (i < toks.length) throw new Error("表达式多余内容: " + src);
    f.vars = vars;
    return f;
  }

  /* ---------- distributions ---------- */
  function makeDist(d) {
    if (typeof d === "number" || typeof d === "string") { const c = compile(d); return (e) => c(e); }
    if (!d || !d.dist) throw new Error("分布格式错误: " + JSON.stringify(d));
    const p = {};
    for (const k of Object.keys(d)) if (k !== "dist") p[k] = compile(d[k]);
    switch (d.dist) {
      case "const": return (e) => p.value(e);
      case "exp": return (e, r) => -p.mean(e) * Math.log(1 - r());
      case "uniform": return (e, r) => { const a = p.min(e), b = p.max(e); return a + (b - a) * r(); };
      case "tri": return (e, r) => {
        const a = p.min(e), c = p.mode(e), b = p.max(e), u = r(), F = (c - a) / (b - a || 1);
        return u < F ? a + Math.sqrt(u * (b - a) * (c - a)) : b - Math.sqrt((1 - u) * (b - a) * (b - c));
      };
      case "normal": return (e, r) => Math.max(0, p.mean(e) + p.sd(e) * Math.sqrt(-2 * Math.log(1 - r())) * Math.cos(2 * Math.PI * r()));
      default: throw new Error("不支持的分布: " + d.dist);
    }
  }
  function distMean(d, env) {
    if (typeof d !== "object") return compile(d)(env);
    const v = (k) => compile(d[k])(env);
    return { const: () => v("value"), exp: () => v("mean"), uniform: () => (v("min") + v("max")) / 2,
      tri: () => (v("min") + v("mode") + v("max")) / 3, normal: () => v("mean") }[d.dist]();
  }

  /* ---------- helpers ---------- */
  function paramEnv(spec, overrides) {
    const env = {};
    for (const p of spec.params || []) env[p.id] = overrides && overrides[p.id] != null ? +overrides[p.id] : +p.value;
    return env;
  }
  function grid(spec) {
    const H = +spec.time.horizon, n = Math.max(2, Math.min(400, spec.time.points || 200));
    const out = [];
    for (let k = 0; k <= n; k++) out.push((H * k) / n);
    return out;
  }
  class Heap {
    constructor() { this.a = []; }
    push(x) { const a = this.a; a.push(x); let i = a.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (lt(a[i], a[p])) { [a[i], a[p]] = [a[p], a[i]]; i = p; } else break; } }
    pop() { const a = this.a, top = a[0], last = a.pop(); if (a.length) { a[0] = last; let i = 0; for (;;) { const l = 2 * i + 1, r = l + 1; let m = i; if (l < a.length && lt(a[l], a[m])) m = l; if (r < a.length && lt(a[r], a[m])) m = r; if (m === i) break; [a[i], a[m]] = [a[m], a[i]]; i = m; } } return top; }
    get size() { return this.a.length; }
  }
  const lt = (x, y) => x.t < y.t || (x.t === y.t && x.s < y.s);

  /* ---------- DES ---------- */
  function runDES(spec, env, seed, record) {
    const r = rng(seed), H = +spec.time.horizon, G = grid(spec);
    const B = {}, order = spec.blocks.map((b) => b.id);
    for (const b of spec.blocks) {
      const x = { def: b, id: b.id, type: b.type, next: b.next };
      if (b.type === "source") { x.ia = makeDist(b.interarrival); x.made = 0; x.limit = b.limit != null ? compile(b.limit)(env) : Infinity; }
      if (b.type === "service") {
        x.cap = Math.max(1, Math.round(compile(b.capacity ?? 1)(env)));
        x.dur = makeDist(b.duration);
        x.qmax = b.queueMax != null ? compile(b.queueMax)(env) : Infinity;
        Object.assign(x, { q: [], busy: 0, qArea: 0, bArea: 0, last: 0, maxQ: 0, waits: 0, nWait: 0, balked: 0, served: 0 });
      }
      if (b.type === "delay") { x.dur = makeDist(b.duration); x.inside = 0; }
      if (b.type === "select") x.br = b.branches.map((br) => ({ p: br.p === "rest" || br.p == null ? null : compile(br.p), next: br.next }));
      if (b.type === "sink") { x.out = 0; x.tis = 0; }
      B[b.id] = x;
    }
    const ev = new Heap();
    let seq = 0, now = 0, inSys = 0, lost = 0, created = 0;
    const at = (t, fn) => ev.push({ t, s: seq++, fn });
    const svc = order.filter((id) => B[id].type === "service"), dly = order.filter((id) => B[id].type === "delay");
    const series = { inSys: [] };
    svc.forEach((id) => (series["q_" + id] = []));
    const snaps = record ? [] : null;
    let gi = 0;
    function snapTo(t) {
      while (gi < G.length && G[gi] <= t) {
        series.inSys.push(inSys);
        svc.forEach((id) => series["q_" + id].push(B[id].q.length));
        if (snaps) snaps.push({ t: G[gi], q: svc.map((id) => B[id].q.length), b: svc.map((id) => B[id].busy), d: dly.map((id) => B[id].inside),
          made: order.filter((id) => B[id].type === "source").map((id) => B[id].made), out: order.filter((id) => B[id].type === "sink").map((id) => B[id].out), lost });
        gi++;
      }
    }
    function acc(x, t) { x.qArea += x.q.length * (t - x.last); x.bArea += x.busy * (t - x.last); x.last = t; }
    function route(e, id) {
      const x = B[id];
      if (!x) throw new Error("找不到下一个环节: " + id);
      if (x.type === "service") {
        acc(x, now);
        if (x.busy < x.cap) start(x, e);
        else if (x.q.length >= x.qmax) { x.balked++; lost++; inSys--; }
        else { e.qs = now; x.q.push(e); if (x.q.length > x.maxQ) x.maxQ = x.q.length; }
      } else if (x.type === "delay") {
        x.inside++;
        at(now + x.dur(env, r), () => { x.inside--; route(e, x.next); });
      } else if (x.type === "select") {
        let u = r(), acc2 = 0, target = null;
        for (const br of x.br) { if (br.p) { acc2 += br.p(env); if (u < acc2) { target = br.next; break; } } }
        if (!target) { const rest = x.br.find((b) => !b.p); target = rest ? rest.next : x.br[x.br.length - 1].next; }
        route(e, target);
      } else if (x.type === "sink") { x.out++; x.tis += now - e.born; inSys--; }
      else throw new Error("实体不能进入环节: " + id);
    }
    function start(x, e) {
      x.busy++; x.served++;
      x.waits += now - (e.qs ?? now); x.nWait++; e.qs = undefined;
      at(now + x.dur(env, r), () => {
        acc(x, now); x.busy--;
        route(e, x.next);
        if (x.q.length) { acc(x, now); start(x, x.q.shift()); }
      });
    }
    for (const id of order) {
      const x = B[id];
      if (x.type !== "source") continue;
      const arrive = () => {
        if (x.made >= x.limit) return;
        x.made++; created++; inSys++;
        route({ born: now }, x.next);
        const nt = now + x.ia(env, r);
        if (nt <= H) at(nt, arrive);
      };
      const first = x.ia(env, r);
      if (first <= H) at(first, arrive);
    }
    while (ev.size) {
      const e = ev.pop();
      if (e.t > H) break;
      snapTo(e.t - 1e-12);
      now = e.t;
      e.fn();
    }
    now = H; snapTo(H);
    svc.forEach((id) => acc(B[id], H));
    const k = {};
    let outN = 0, tis = 0;
    order.forEach((id) => { const x = B[id]; if (x.type === "sink") { outN += x.out; tis += x.tis; } });
    k.throughput = outN; k.tis = outN ? tis / outN : 0; k.lost = lost; k.created = created;
    for (const id of svc) {
      const x = B[id];
      k["wait_" + id] = x.nWait ? x.waits / x.nWait : 0;
      k["util_" + id] = (x.bArea / (H * x.cap)) * 100;
      k["maxq_" + id] = x.maxQ;
      k["avgq_" + id] = x.qArea / H;
      k["balk_" + id] = x.balked;
    }
    return { k, series, snaps, t: G };
  }

  /* ---------- SD ---------- */
  function topo(items, known) {
    const left = items.slice(), out = [], have = new Set(known);
    while (left.length) {
      const i = left.findIndex((a) => [...a.f.vars].every((v) => have.has(v) || !left.some((b) => b.id === v)));
      if (i < 0) throw new Error("辅助变量之间有循环依赖: " + left.map((a) => a.id).join(", "));
      const a = left.splice(i, 1)[0]; out.push(a); have.add(a.id);
    }
    return out;
  }
  function runSD(spec, env0) {
    const H = +spec.time.horizon, dt = +(spec.time.dt || 1), G = grid(spec);
    const env = Object.assign({ t: 0, dt }, env0);
    const stocks = spec.stocks.map((s) => ({ id: s.id, init: compile(s.initial), min: s.min }));
    stocks.forEach((s) => (env[s.id] = s.init(env)));
    const flows = (spec.flows || []).map((f) => ({ id: f.id, from: f.from, to: f.to, f: compile(f.rate) }));
    const aux = topo((spec.aux || []).map((a) => ({ id: a.id, f: compile(a.expr) })), Object.keys(env));
    const names = stocks.map((s) => s.id).concat(flows.map((f) => f.id), aux.map((a) => a.id));
    const series = {}; names.forEach((n) => (series[n] = []));
    const evalAll = () => { aux.forEach((a) => (env[a.id] = a.f(env))); flows.forEach((f) => (env[f.id] = f.f(env))); aux.forEach((a) => (env[a.id] = a.f(env))); };
    let gi = 0;
    const steps = Math.round(H / dt);
    for (let s = 0; s <= steps; s++) {
      env.t = s * dt;
      evalAll();
      while (gi < G.length && G[gi] <= env.t + dt / 2) { names.forEach((n) => series[n].push(env[n])); gi++; }
      if (s === steps) break;
      const d = {};
      flows.forEach((f) => { const v = env[f.id] * dt; if (f.from) d[f.from] = (d[f.from] || 0) - v; if (f.to) d[f.to] = (d[f.to] || 0) + v; });
      stocks.forEach((st) => { env[st.id] += d[st.id] || 0; if (st.min != null && env[st.id] < st.min) env[st.id] = st.min; });
    }
    while (series[names[0]].length < G.length) names.forEach((n) => series[n].push(series[n][series[n].length - 1]));
    return { k: {}, series, snaps: null, t: G };
  }

  /* ---------- ABM ---------- */
  function runABM(spec, env0, seed, record) {
    const r = rng(seed), H = +spec.time.horizon, dt = +(spec.time.dt || 1), G = grid(spec);
    const env = Object.assign({ t: 0 }, env0);
    const N = Math.max(1, Math.round(compile(spec.population)(env)));
    env.N = N;
    const S = spec.states.map((s) => s.id), idx = Object.fromEntries(S.map((s, i) => [s, i]));
    const st = new Uint8Array(N);
    let pos = 0;
    for (const [sid, ex] of Object.entries(spec.initial || {})) {
      const n = Math.min(N - pos, Math.max(0, Math.round(compile(ex)(env))));
      for (let j = 0; j < n; j++) st[pos++] = idx[sid];
    }
    for (let i = N - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [st[i], st[j]] = [st[j], st[i]]; }
    const tr = spec.transitions.map((x) => ({ from: idx[x.from], to: idx[x.to], type: x.type || "rate",
      rate: x.rate != null ? compile(x.rate) : null, contacts: x.contacts != null ? compile(x.contacts) : null,
      prob: x.prob != null ? compile(x.prob) : null, withS: x.with != null ? idx[x.with] : null }));
    tr.forEach((x, i) => { if (x.from == null || x.to == null) throw new Error("状态转换引用了不存在的状态: " + JSON.stringify(spec.transitions[i])); });
    const series = {}; S.forEach((s) => (series[s] = []));
    const snaps = record ? [] : null;
    const counts = () => { const c = new Array(S.length).fill(0); for (let i = 0; i < N; i++) c[st[i]]++; return c; };
    let gi = 0;
    const steps = Math.round(H / dt);
    for (let s = 0; s <= steps; s++) {
      env.t = s * dt;
      const c = counts();
      S.forEach((sid, i) => (env[sid] = c[i]));
      while (gi < G.length && G[gi] <= env.t + dt / 2) { S.forEach((sid, i) => series[sid].push(c[i])); if (snaps) snaps.push({ t: G[gi], s: st.slice() }); gi++; }
      if (s === steps) break;
      const pre = tr.map((x) => ({ p: x.rate ? 1 - Math.exp(-Math.max(0, x.rate(env)) * dt) : 0,
        k: x.contacts ? Math.max(0, x.contacts(env)) * dt : 0, q: x.prob ? x.prob(env) : 1 }));
      const old = st.slice();
      for (let i = 0; i < N; i++) {
        for (let j = 0; j < tr.length; j++) {
          const x = tr[j];
          if (x.from !== old[i]) continue;
          const p = pre[j];
          let fire = false;
          if (x.type === "rate") fire = r() < p.p;
          else {
            let n = Math.floor(p.k); if (r() < p.k - n) n++;
            for (let m = 0; m < n && !fire; m++) { const o = old[Math.floor(r() * N)]; if (o === x.withS && r() < p.q) fire = true; }
          }
          if (fire) { st[i] = x.to; break; }
        }
      }
    }
    return { k: {}, series, snaps, t: G, N };
  }

  /* ---------- KPIs, replications ---------- */
  function seriesKpi(def, run, env) {
    const s = run.series[def.var];
    if (!s) throw new Error("指标引用了不存在的序列: " + def.var);
    const t = run.t;
    switch (def.type || "final") {
      case "final": return s[s.length - 1];
      case "max": return Math.max(...s);
      case "min": return Math.min(...s);
      case "mean": return s.reduce((a, b) => a + b, 0) / s.length;
      case "timeOfMax": return t[s.indexOf(Math.max(...s))];
      case "firstTime": {
        const v = def.valueParam != null && env && env[def.valueParam] != null ? +env[def.valueParam] : +def.value, op = def.op || ">=";
        const ok = (x) => (op === ">=" ? x >= v : op === "<=" ? x <= v : op === ">" ? x > v : x < v);
        const i = s.findIndex(ok);
        return i < 0 ? null : t[i];
      }
      default: throw new Error("不支持的指标类型: " + def.type);
    }
  }
  /* text fields may be plain strings or {zh, en} */
  function pick(v, lang) {
    if (v && typeof v === "object" && !Array.isArray(v) && ("zh" in v || "en" in v)) return v[lang] ?? v.zh ?? v.en;
    return v;
  }
  function builtinKpis(spec) {
    if (spec.method !== "des") return [];
    const u = spec.time.unit || { zh: "分钟", en: "min" }, ppl = { zh: "人", en: "people" }, out = [];
    const L2 = (b, zh, en) => ({ zh: (pick(b.label, "zh") || b.id) + "：" + zh, en: (pick(b.label, "en") || b.id) + ": " + en });
    for (const b of spec.blocks) {
      if (b.type !== "service") continue;
      out.push({ id: "wait_" + b.id, label: L2(b, "平均排队", "average wait"), unit: u, good: "low" });
      out.push({ id: "maxq_" + b.id, label: L2(b, "最长队伍", "longest queue"), unit: ppl, good: "low", digits: 0 });
      out.push({ id: "util_" + b.id, label: L2(b, "忙碌程度", "how busy"), unit: "%", good: "mid", digits: 0 });
      if (b.queueMax != null) out.push({ id: "balk_" + b.id, label: L2(b, "嫌队长离开", "left because of the line"), unit: ppl, good: "low", digits: 0 });
    }
    out.push({ id: "throughput", label: { zh: "完成服务", en: "Served" }, unit: ppl, good: "high", digits: 0 });
    out.push({ id: "tis", label: { zh: "平均总停留", en: "Average total time" }, unit: u, good: "low" });
    return out;
  }
  function pct(a, p) { if (!a.length) return null; const s = a.slice().sort((x, y) => x - y), i = (s.length - 1) * p, lo = Math.floor(i); return s[lo] + (s[Math.ceil(i)] - s[lo]) * (i - lo); }

  function run(spec, overrides, opts) {
    opts = opts || {};
    const env = paramEnv(spec, overrides);
    const reps = spec.method === "sd" ? 1 : Math.max(1, opts.reps || spec.replications || 20);
    const seed0 = opts.seed ?? 12345;
    const runs = [];
    for (let k = 0; k < reps; k++) {
      const rec = k === 0 && opts.record !== false;
      const e = Object.assign({}, env);
      runs.push(spec.method === "des" ? runDES(spec, e, seed0 + k * 7919, rec)
        : spec.method === "sd" ? runSD(spec, e) : runABM(spec, e, seed0 + k * 7919, rec));
    }
    const defs = builtinKpis(spec).concat(spec.kpis || []);
    const kpis = defs.map((d) => {
      const vals = runs.map((rn) => (d.var ? seriesKpi(d, rn, env) : rn.k[d.id])).filter((v) => v != null && isFinite(v));
      return Object.assign({}, d, { mean: vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : null,
        lo: pct(vals, 0.05), hi: pct(vals, 0.95), hit: vals.length, n: runs.length });
    });
    const series = {};
    for (const name of Object.keys(runs[0].series)) {
      const cols = runs[0].series[name].map((_, i) => runs.map((rn) => rn.series[name][i]));
      series[name] = { mean: cols.map((c) => c.reduce((a, b) => a + b, 0) / c.length), lo: cols.map((c) => pct(c, 0.05)), hi: cols.map((c) => pct(c, 0.95)) };
    }
    return { kpis, series, t: runs[0].t, anim: runs[0].snaps, N: runs[0].N, reps, env };
  }

  /* ---------- validation ---------- */
  function validate(spec) {
    const errs = [];
    const need = (c, m) => { if (!c) errs.push(m); };
    need(spec && spec.title, "缺少 title");
    need(["des", "sd", "abm"].includes(spec && spec.method), "method 必须是 des / sd / abm");
    need(spec && spec.time && +spec.time.horizon > 0, "time.horizon 必须大于 0");
    if (errs.length) return errs;
    const ids = new Set((spec.params || []).map((p) => p.id));
    (spec.params || []).forEach((p) => {
      need(/^[A-Za-z_]\w*$/.test(p.id || ""), "参数 id 只能用英文字母、数字、下划线: " + p.id);
      need(p.label, "参数缺少 label: " + p.id);
      if (p.min != null && p.max != null) need(+p.min <= +p.value && +p.value <= +p.max, "参数默认值不在 min~max 内: " + p.id);
    });
    if (spec.method === "des") {
      const bid = new Set(spec.blocks.map((b) => b.id));
      need(spec.blocks.some((b) => b.type === "source"), "流程模型至少需要一个 source");
      need(spec.blocks.some((b) => b.type === "sink"), "流程模型至少需要一个 sink");
      spec.blocks.forEach((b) => {
        need(["source", "service", "delay", "select", "sink"].includes(b.type), "未知环节类型: " + b.type);
        if (b.type !== "sink" && b.type !== "select") need(bid.has(b.next), b.id + " 的 next 指向不存在的环节: " + b.next);
        if (b.type === "select") (b.branches || []).forEach((br) => need(bid.has(br.next), b.id + " 的分支指向不存在的环节: " + br.next));
      });
    }
    if (!errs.length) {
      try { run(spec, null, { reps: 1, record: false }); } catch (e) { errs.push("试运行失败: " + e.message); }
    }
    void ids;
    return errs;
  }

  const api = { run, validate, compile, distMean, builtinKpis, paramEnv, pick, version: "0.2.0" };
  root.SimEngine = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
